#!/bin/bash
if [[ "$1" == "-h" ]]; then
echo "Uso: $0 directorio_destino"
echo "Este script realiza un backup del directorio_origen en el directorio_destino."
exit 0
fi

if [[ $# -ne 2 ]]; then
echo "Error: Debe proporcionar el directorio de origen y de destino."
exit 1
fi

ORIGEN=$1
DESTINO=$2

if [[ ! -d "$ORIGEN" ]]; then
echo "Error: El directorio de origen $ORIGEN no existe o no esta montado."
exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
echo "Error: El directorio de destino $DESTINO no exite o no esta montado."
exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE_BACKUP=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz
tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN"

if [[ $? -eq 0 ]]; then
echo "Backup de $ORIGEN realizado existosamente en $DESTINO/$NOMBRE_BACKUP"
else
echo "Error al realizar el backup de $ORIGEN"
fi

